from typing import Dict, List
from fastapi import APIRouter, HTTPException, Depends

from app.api.deps import pagination
from app.schemas.item import ItemCreate, ItemRead

router = APIRouter()

# In-memory storage for demo purposes
_items: Dict[int, ItemRead] = {}
_next_id: int = 1


@router.post("", response_model=ItemRead, summary="Создать товар")
def create_item(payload: ItemCreate) -> ItemRead:
    global _next_id
    item = ItemRead(id=_next_id, **payload.model_dump())
    _items[_next_id] = item
    _next_id += 1
    return item


@router.get("/{item_id}", response_model=ItemRead, summary="Получить товар по ID")
def get_item(item_id: int) -> ItemRead:
    item = _items.get(item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Товар не найден")
    return item


@router.get("", response_model=List[ItemRead], summary="Список товаров")
def list_items(p: dict = Depends(pagination)) -> List[ItemRead]:
    items = list(_items.values())
    start = p["skip"]
    end = start + p["limit"]
    return items[start:end]
