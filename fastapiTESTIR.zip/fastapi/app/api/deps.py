from typing import Optional
from fastapi import Query


def pagination(
    skip: int = Query(0, ge=0, description="Number of items to skip"),
    limit: int = Query(10, ge=1, le=100, description="Max items to return"),
):
    return {"skip": skip, "limit": limit}

