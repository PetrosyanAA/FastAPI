from pydantic import BaseModel, Field, PositiveInt
from typing import Optional, Set


class ItemBase(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    price: float = Field(ge=0)
    quantity: PositiveInt = Field(default=1)
    tags: Optional[Set[str]] = Field(default=None, min_length=0, max_length=10)


class ItemCreate(ItemBase):
    pass


class ItemRead(ItemBase):
    id: int
