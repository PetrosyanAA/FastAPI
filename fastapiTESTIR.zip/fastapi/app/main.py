from fastapi import FastAPI
from fastapi.responses import RedirectResponse

from app.core.config import settings
from app.utils.errors import register_exception_handlers
from app.api.v1 import api_router

app = FastAPI(title=settings.app_name, version="1.0.0", description="API-пример с автодокументацией и валидацией данных")


@app.get("/", include_in_schema=False)
def root():
    return RedirectResponse(url="/docs")


@app.get("/health", tags=["сервис"], summary="Проверка состояния")
def health_check() -> dict:
    return {"status": "ok"}


# Mount API v1
app.include_router(api_router, prefix=settings.api_v1_str)


# Register error handlers
register_exception_handlers(app)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=True)
